import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  ProducerForm: FormGroup;
  ConsumerForm: FormGroup;
  selectedFile: File;
  topics: any;
  fileContent: string | ArrayBuffer;
  fileData: any;
  consumerData: any;
  consumerValue: any
  baseUrl: string = "http://localhost:8080/producer/message";
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.createProducerForm();
    //this.createConsumerForm();
  }

  ngOnInit() {
    this.topics = [{
      "topicId": 1,
      "topicName": "myFirstTopic"
    },
    {
      "topicId": 2,
      "topicName": "secondtopic"
    }]
  }

  createProducerForm() {
    this.ProducerForm = this.formBuilder.group({
      fullName: [''],
      message: [''],
      topicName: ['']
    });
  }

  
  // createConsumerForm() {
  //   this.ConsumerForm = this.formBuilder.group({
  //     consumerMessage: [''],
  //   });
  // }
  onSubmit() {
    console.log('Your form data : ', this.ProducerForm.value);
    console.log('file value', this.fileContent);
    const saveProducerUserMessage: any = {
      fullName: this.ProducerForm.controls.fullName.value,
      message: this.ProducerForm.controls.message.value,
      topicName: this.ProducerForm.controls.topicName.value,
      fileContent: this.fileContent
    }
    console.log("const ", saveProducerUserMessage);
    this.saveProducerData(saveProducerUserMessage).subscribe((response) =>{
    console.log('response from server', response);
    });

    
  }
   consumerResponse(){
    this.getConsumerData().subscribe((response) =>{
    console.log('response from Consumer Server server', response);
    
    this.consumerValue = JSON.stringify(response);;
      });
      // this.ConsumerForm.patchValue({ consumerMessage: this.consumerData,
      //    });

    }

  onFileSelected(fileList: FileList) {
    let file = fileList[0];
    let fileReader: FileReader = new FileReader();
    let self = this;
    fileReader.onloadend = function(x) {
      self.fileContent = fileReader.result;
    }
    fileReader.readAsText(file);
  }

    // Save Producer data.
    // this ia a rest call
    public saveProducerData(saveProducerUserMessage: any): Observable<any> {
     // tslint:disable-next-line: max-line-length
      return this.http.post<any>("http://localhost:8080/message", saveProducerUserMessage);
    }
    
    // Save Producer data.
    public getConsumerData(): Observable<any> {
      // tslint:disable-next-line: max-line-length
      return this.http.get<any>("http://localhost:5762/getConsumerMessage");
    }

}
