package com.example.Consumer;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConsumerController {
	
	@Autowired
	private ConsumerApplication consumer;	
	
	
	@RequestMapping(value = "/getConsumerMessage" , method = RequestMethod.GET)
	public ResponseEntity<JSONArray> consumer() {
		
		System.out.println("******* Fetching consumer messages ******");
		JSONArray response = consumer.getConsumerMessages();
		System.out.println("response"+ response.toJSONString());
		ResponseEntity<JSONArray> finalResponse = new ResponseEntity<JSONArray>(response,HttpStatus.OK);
		
		return finalResponse;
	}

}
