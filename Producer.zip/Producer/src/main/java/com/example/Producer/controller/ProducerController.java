package com.example.Producer.controller;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProducerController {

	  @Autowired
	    private Producer producer; 


    @RequestMapping(value= "/message", method = RequestMethod.POST)
    public ResponseEntity<JSONObject> singleFileUpload(@RequestBody String file) {

                 // producer call 
           // producer.sendMessage(bytes.toString());
    	   System.out.println(file);
            producer.ProduceMessge(file);
            JSONObject obj = new JSONObject();
            obj.put("name", "response from backend server");
            obj.put("value", 100);
            
            ResponseEntity<JSONObject> response = new ResponseEntity<JSONObject>(obj, HttpStatus.OK);
            
            return response;

         }

}
