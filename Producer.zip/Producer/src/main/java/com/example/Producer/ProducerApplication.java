package com.example.Producer;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

@SpringBootApplication
public class ProducerApplication {

	//private static KafkaProducer<String, String> producer;
	 // public static  KafkaProducer<String, String> producer;
	public static void main(String[] args) throws InterruptedException {
		SpringApplication.run(ProducerApplication.class, args);
//		String  bootstratServer="127.0.0.1:9092";
//		String topicName="secondtopic";
//		
//		 Properties properties = new Properties();
//
//		  // Populate producer configurations
//		  properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstratServer);
//		  properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
//		  properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
//		  properties.put(ProducerConfig.ACKS_CONFIG, "1");
//		  
//		  try (KafkaProducer<String, String> producer = new KafkaProducer<>(properties)) {
//			   
//				  
//			    
//
//			    ProducerRecord<String, String> record = new ProducerRecord<>(topicName, "key", "hello everyone");
//			    System.out.println("producerapplication is running");
//
//			    producer.send(record);
//			   // TimeUnit.SECONDS.sleep(5);
//	
// 
//			   }
//			   
//			  }
		
		   
//			 }
		
		
		
	
	}}

